from django.shortcuts import render, get_object_or_404, redirect
from .models import Player
from .forms import PlayerForm

def add_player(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        bio = request.POST.get('bio')
        age = request.POST.get('age')
        sport = request.POST.get('sport')
        emoticon = request.POST.get('emoticon')

        try:
            age = int(age)  # Ensure age is an integer
        except ValueError:
            age = None  # Handle invalid age input if necessary


        # Create a new Player object and save it
        new_player = Player(name=name, bio=bio, age=age, sport=sport, emoticon=emoticon)
        new_player.save()

        # Redirect to home after saving the player
        return redirect('home')  # Assuming 'home' is the name of the URL for the home page

    return render(request, 'players/add_player.html')

def home(request):
    # Get all players from the database and pass them to the template
    players = Player.objects.all()
    return render(request, 'players/home.html', {'players': players})

def edit_player(request, pk):
    player = get_object_or_404(Player, pk=pk)
    if request.method == 'POST':
        form = PlayerForm(request.POST, request.FILES, instance=player)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = PlayerForm(instance=player)
    return render(request, 'players/edit_player.html', {'form': form})

def delete_player(request, pk):
    player = get_object_or_404(Player, pk=pk)
    player.delete()
    return redirect('home')
