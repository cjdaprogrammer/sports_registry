from django.db import models

class Player(models.Model):
    name = models.CharField(max_length=100)
    bio = models.TextField()
    sport = models.CharField(max_length=100)
    emoticon = models.CharField(max_length=10)
    age = models.IntegerField()  # Make age optional

    def __str__(self):
        return self.name
